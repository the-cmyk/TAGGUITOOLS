
#include "argsParser.h"
#include "buffers.h"
#include "common.h"
#include "logger.h"
#include "parserOnnxConfig.h"

#include "NvInfer.h"
#include <cuda_runtime_api.h>

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <chrono>

const std::string gSampleName = "TensorRT.insightface";

class insightface
{
    template <typename T>
    using SampleUniquePtr = std::unique_ptr<T, samplesCommon::InferDeleter>;

public:
    insightface(const samplesCommon::OnnxSampleParams& params)
        : mParams(params)
        , mEngine(nullptr)
    {
    }

    bool build();

    bool infer();

private:

    static const int kIMG_CHANNELS = 3;
    static const int kIMG_H = 112;
    static const int kIMG_W = 112;
    std::vector<samplesCommon::PPM<kIMG_CHANNELS, kIMG_H, kIMG_W>> mPPMs; //!< PPMs of test images


    samplesCommon::OnnxSampleParams mParams; //!< The parameters for the sample.

    nvinfer1::Dims mInputDims;  //!< The dimensions of the input to the network.
    nvinfer1::Dims mOutputDims; //!< The dimensions of the output to the network.

    std::shared_ptr<nvinfer1::ICudaEngine> mEngine; //!< The TensorRT engine used to run the network

    bool constructNetwork(SampleUniquePtr<nvinfer1::IBuilder>& builder,
        SampleUniquePtr<nvinfer1::INetworkDefinition>& network, SampleUniquePtr<nvinfer1::IBuilderConfig>& config,
        SampleUniquePtr<nvonnxparser::IParser>& parser);

    //!
    //! \brief Reads the input and stores the result in a managed buffer
    //!
    bool processInput(const samplesCommon::BufferManager& buffers);

};

bool insightface::build()
{

    ifstream f("insightface_B4_FP16.engine");
    if (!f.good()){

        auto builder = SampleUniquePtr<nvinfer1::IBuilder>(nvinfer1::createInferBuilder(gLogger.getTRTLogger()));
        if (!builder)
        {
            return false;
        }

        auto network = SampleUniquePtr<nvinfer1::INetworkDefinition>(builder->createNetwork());
        if (!network)
        {
            return false;
        }

        auto config = SampleUniquePtr<nvinfer1::IBuilderConfig>(builder->createBuilderConfig());
        if (!config)
        {
            return false;
        }

        auto parser = SampleUniquePtr<nvonnxparser::IParser>(nvonnxparser::createParser(*network, gLogger.getTRTLogger()));
        if (!parser)
        {
            return false;
        }

        auto constructed = constructNetwork(builder, network, config, parser);
        if (!constructed)
        {
            return false;
        }

        mEngine = std::shared_ptr<nvinfer1::ICudaEngine>(builder->buildEngineWithConfig(*network, *config), samplesCommon::InferDeleter());
        if (!mEngine)
        {
            return false;
        }

        assert(network->getNbInputs() == 1);
        mInputDims = network->getInput(0)->getDimensions();
        assert(mInputDims.nbDims == 3);

        assert(network->getNbOutputs() == 1);
        mOutputDims = network->getOutput(0)->getDimensions();
        assert(mOutputDims.nbDims == 1);


        IHostMemory *trtModelStream = mEngine->serialize();
        ofstream p("insightface_B4_FP16.engine");
        p.write((const char*)trtModelStream->data(),trtModelStream->size());
        p.close();

    }else{

        std::stringstream planBuffer;
        planBuffer << f.rdbuf();
        std::string plan = planBuffer.str();
        IRuntime *runtime = createInferRuntime(gLogger);
        ICudaEngine *engine = runtime->deserializeCudaEngine((void*)plan.data(), plan.size(), nullptr);

        mEngine = std::shared_ptr<nvinfer1::ICudaEngine>(engine, samplesCommon::InferDeleter());
    }
    return true;
}

bool insightface::constructNetwork(SampleUniquePtr<nvinfer1::IBuilder>& builder,
    SampleUniquePtr<nvinfer1::INetworkDefinition>& network, SampleUniquePtr<nvinfer1::IBuilderConfig>& config,
    SampleUniquePtr<nvonnxparser::IParser>& parser)
{
    auto parsed = parser->parseFromFile(
        "/insightface/resnet100.onnx", static_cast<int>(gLogger.getReportableSeverity()));
    if (!parsed)
    {
        return false;
    }

    builder->setMaxBatchSize(mParams.batchSize);
    config->setMaxWorkspaceSize(512_MiB);
    if (mParams.fp16)
    {
        config->setFlag(BuilderFlag::kFP16);
    }
    if (mParams.int8)
    {
        config->setFlag(BuilderFlag::kINT8);
        samplesCommon::setAllTensorScales(network.get(), 127.0f, 127.0f);
    }

    samplesCommon::enableDLA(builder.get(), config.get(), mParams.dlaCore);

    return true;
}

//!
//! \brief Runs the TensorRT inference engine for this sample
//!
//! \details This function is the main execution function of the sample. It allocates the buffer,
//!          sets inputs and executes the engine.
//!
bool insightface::infer()
{
    using milli = std::chrono::milliseconds;
    auto start = std::chrono::high_resolution_clock::now();

    // Create RAII buffer manager object
    samplesCommon::BufferManager buffers(mEngine, mParams.batchSize);

    auto finish0 = std::chrono::high_resolution_clock::now();
    std::cout << "new buffers() took " << std::chrono::duration_cast<milli>(finish0 - start).count()
            << " milliseconds\n";

    auto context = SampleUniquePtr<nvinfer1::IExecutionContext>(mEngine->createExecutionContext());
    if (!context)
    {
        return false;
    }

    auto finish_ = std::chrono::high_resolution_clock::now();
    std::cout << "createExecutionContext()) took " << std::chrono::duration_cast<milli>(finish_ - finish0).count()
            << " milliseconds\n";

    for (int i=0;i<200;i++){

        auto finish_ = std::chrono::high_resolution_clock::now();

        // Read the input data into the managed buffers
        assert(mParams.inputTensorNames.size() == 1);
        if (!processInput(buffers))
        {
            return false;
        }


        // Memcpy from host input buffers to device input buffers
        buffers.copyInputToDevice();

        auto finish = std::chrono::high_resolution_clock::now();
        std::cout << "copyInputToDevice() took " << std::chrono::duration_cast<milli>(finish - finish_).count()
                << " milliseconds\n";

        bool status = context->execute(mParams.batchSize, buffers.getDeviceBindings().data());
        if (!status)
        {
            return false;
        }

        auto finish2 = std::chrono::high_resolution_clock::now();
        std::cout << "context->execute() took " << std::chrono::duration_cast<milli>(finish2 - finish).count()
                << " milliseconds\n";

        // Memcpy from device output buffers to host output buffers
        buffers.copyOutputToHost();

        auto finish3 = std::chrono::high_resolution_clock::now();
        std::cout << "copyOutputToHost() took " << std::chrono::duration_cast<milli>(finish3 - finish2).count()
                << " milliseconds\n";
        
        // float* hostDataBuffer = static_cast<float*>(buffers.getHostBuffer("fc1"));
        // for (int i = 0;i < 512; ++i)
        // {
        //     // The color image to input should be in BGR order
        //     cout << i << " "<< hostDataBuffer[i] <<endl;
        // }

        std::filebuf fb;
        fb.open ("test.txt",std::ios::out);
        std::ostream os(&fb);
        buffers.dumpBuffer(os,"fc1");    
    }
    return true;
}

//!
//! \brief Reads the input and stores the result in a managed buffer
//!
bool insightface::processInput(const samplesCommon::BufferManager& buffers)
{
    const int inputC = 3;
    const int inputH = 112;
    const int inputW = 112;
    const int batchSize = mParams.batchSize;

    // Available images
    const std::vector<std::string> imageList = {"sample-images/0.ppm","sample-images/1.ppm","sample-images/2.ppm","sample-images/3.ppm"};//, "000542.ppm", "001150.ppm", "001763.ppm", "004545.ppm"};
    mPPMs.resize(batchSize);
    assert(mPPMs.size() <= imageList.size());

    for (int i = 0; i < batchSize; ++i)
    {
        readPPMFile(locateFile(imageList[i], mParams.dataDirs), mPPMs[i]);
    }

    // Fill data buffer
    float* hostDataBuffer = static_cast<float*>(buffers.getHostBuffer("data"));

    for (int i = 0, volImg = inputC * inputH * inputW; i < batchSize; ++i)
    {
        for (int c = 0; c < inputC; ++c)
        {
            // The color image to input should be in BGR order
            for (unsigned j = 0, volChl = inputH * inputW; j < volChl; ++j){

                hostDataBuffer[i * volImg + c * volChl + j] = float(mPPMs[i].buffer[j * inputC + 2 - c]);
            }
        }
    }

    return true;
}

//!
//! \brief Initializes members of the params struct using the command line args
//!
samplesCommon::OnnxSampleParams initializeSampleParams(const samplesCommon::Args& args)
{
    samplesCommon::OnnxSampleParams params;
    if (args.dataDirs.empty()) //!< Use default directories if user hasn't provided directory paths
    {
        params.dataDirs.push_back("/insightface/");
    }
    else //!< Use the data directory provided by the user
    {
        params.dataDirs = args.dataDirs;
    }
    params.onnxFileName = "/insightface/resnet100.onnx";
    params.inputTensorNames.push_back("data");
    params.batchSize = 4;
    //params.outputTensorNames.push_back("Plus214_Output_0");
    params.dlaCore = args.useDLACore;
    params.int8 = false;
    params.fp16 = true;

    return params;
}

//!
//! \brief Prints the help information for running this sample
//!
void printHelpInfo()
{
    std::cout << "Usage: ./insightface [-h or --help] [-d or --datadir=<path to data directory>] [--useDLACore=<int>]" << std::endl;
    std::cout << "--help          Display help information" << std::endl;
    std::cout << "--datadir       Specify path to a data directory, overriding the default. This option can be used multiple times to add multiple directories. If no data directories are given, the default is to use (data/samples/mnist/, data/mnist/)" << std::endl;
    std::cout << "--useDLACore=N  Specify a DLA engine for layers that support DLA. Value can range from 0 to n-1, where n is the number of DLA engines on the platform." << std::endl;
    std::cout << "--int8          Run in Int8 mode." << std::endl;
    std::cout << "--fp16          Run in FPf16 mode." << std::endl;
}

int main(int argc, char** argv)
{
    samplesCommon::Args args;
    bool argsOK = samplesCommon::parseArgs(args, argc, argv);
    if (!argsOK)
    {
        gLogError << "Invalid arguments" << std::endl;
        printHelpInfo();
        return EXIT_FAILURE;
    }
    if (args.help)
    {
        printHelpInfo();
        return EXIT_SUCCESS;
    }

    auto sampleTest = gLogger.defineTest(gSampleName, argc, argv);

    gLogger.reportTestStart(sampleTest);

    insightface sample(initializeSampleParams(args));

    gLogInfo << "Building and running a GPU inference engine for insightface" << std::endl;
    if (!sample.build())
    {
        return gLogger.reportFail(sampleTest);
    }
    gLogInfo << "built engine" << std::endl;
    
    if (!sample.infer())
    {
        return gLogger.reportFail(sampleTest);
    }

    return gLogger.reportPass(sampleTest);
}
